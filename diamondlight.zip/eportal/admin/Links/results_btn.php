<div class="text-center link">
    <a href="result_uploading"><button type="button" class="btn btn-primary btn-icon badge-pill">Upload Result</button></a>
              <a href="view_uploaded_result"><button type="button" class="btn btn-success btn-icon badge-pill">View Result</button></a> <a href="uploading_behavior"><button type="button" class="btn btn-warning btn-icon badge-pill">Upload Cognitive</button></a> <a href="view_cognitive"><button type="button" class="btn btn-dark btn-icon badge-pill">View Cognitive</button></a> 
            </div>