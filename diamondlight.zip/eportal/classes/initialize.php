<?php 
if (!defined("__OSOTECH__DEV_COMPANY__")) {
	define("__OSOTECH__DEV_COMPANY__", "Osotech");
	define("__OSO_HOST__",'localhost');
	define("__OSO_USER__",'root');
	define("__OSO_PASS__",'osotech');
	define("__OSO_DBNAME__",'diamond_portal');
	/*define("__OSO_USER__",'diamond_admin');
	define("__OSO_PASS__",'@diamond123');
	define("__OSO_DBNAME__",'diamond_portal');*/
	define("__OSO_DB_DRIVER__",'mysql');
	define("__OSO_CHARSET__",'utf8mb4');
	define("__OSO_SERIAL__NUMBER_","XTAS-KM87-EWA6-09CQ-5J0V");
	define("__OSO__CONTROL__KEY__","diamond123");
	define("__OSO_APP_VERSION__","v1.1.1");
	define("__OSO_APP_DEV_YEAR__","2022");
	define("__OSO_APP_NAME__","SMApp");
	define("__SCHOOL_NAME__","E-Portal @ DiamondLight School & College");
	define("__SCHOOL_LOCATION_ADDRESS__","8,Road 20, Golden Estate, Ijagba, Otta,Nigeria");
	define("APP_ROOT","http://localhost/diamondlight/eportal/");
	//define("APP_ROOT","https://eportal.diamondlightschools.com/");
	
}