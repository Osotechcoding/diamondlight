 <footer class="footer footer-static footer-light">
      <p class="clearfix mb-0"><span class="float-left d-inline-block">&copy; <?php echo date("Y");?> <?php echo __OSO_APP_NAME__; ?> <?php echo __OSO_APP_VERSION__; ?> </span><span class="float-right d-sm-inline-block d-none"><?php echo $lang['dev_desc'] ?><i class="bx bxs-heart pink mx-50 font-small-3"></i><?php echo $lang['by'] ?><a class="text-uppercase" href="https://businessapp.com.ng" target="_blank">Osotech Software Inc</a></span>
        <button class="btn btn-primary btn-icon scroll-top" type="button"><i class="bx bx-up-arrow-alt"></i></button>
      </p>
    </footer>