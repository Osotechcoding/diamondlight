<meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
 <meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="<?php echo __SCHOOL_NAME__;?>, Online School Portal, Education is Light, Affordable School Fee, Online Admission Process">
<meta name="keywords" content="Online Student Result Processing, Elementary School, Basic Classes, Primary classes, College, Staff Portal, Student Portal, Admin Portal, Online Admission">
<meta name="author" content="<?php echo __AUTHOR_NAME__;?>">
 <link rel="shortcut icon" href="../assets/images/favicon.png"> 
 <!-- <link rel="icon" href="<?php //echo $Osotech->get_schoolLogoImage();?>">  -->
