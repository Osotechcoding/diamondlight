<div id="loader" class="loader orange-color">
    <div class="loader-container">
        <div class='loader-icon'>
            <img src="../assets/images/pre-logo1.png" alt="">
        </div>
    </div>
</div>
